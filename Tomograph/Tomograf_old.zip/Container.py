import ipywidgets as widgets
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
from skimage.filters import median
from sklearn.metrics import mean_squared_error


# Zdefiniowanie funkcji
def normalize(image):
    min_value = np.min(image)

    max_value = np.max(image)

    for i in range(len(image)):
        for j in range(len(image[i])):
            image[i, j] = (image[i, j] - min_value) / (max_value - min_value)

    return image


def mse(x, y):
    err = np.sum((x.astype("float") - y.astype("float")) ** 2)
    err /= float(len(x) * len(x[0]))
    return err


class Container:
    def __init__(self):
        self.displayContainer = None
        self.fig = None
        self.axes = None

    def createContainer(self):
        self.displayContainer = widgets.Output(layout={'height': '350px'})

        self.fig, self.axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 5))

        self.axes[0].set_title('Obraz wejściowy')
        self.axes[1].set_title('Sinogram')
        self.axes[2].set_title('Obraz wyjściowy')

        self.axes[0].axis('off')
        self.axes[1].axis('off')
        self.axes[2].axis('off')

        plt.close()
        display(self.displayContainer)

    def displayImages(self, tom):
        image = tom.original
        tmp = image[round(len(image) / 4): 3 * round(len(image) / 4),
                    round(len(image[0]) / 4): 3 * round(len(image[0]) / 4)]

        sinogram = normalize(tom.sinograms[-1])
        reverse = normalize(tom.reverses[-1])

        if tom.isFilter:
            reverse = median(np.copy(reverse), selem=np.ones((5, 5)))

        with self.displayContainer:
            clear_output()
            self.axes[0].imshow(image, cmap='gray')
            self.axes[1].imshow(sinogram, cmap='gray')
            self.axes[2].imshow(reverse, cmap='gray')
            print("Błąd średiokwadratowy: " + str(mse(image, reverse)))
            display(self.fig)
